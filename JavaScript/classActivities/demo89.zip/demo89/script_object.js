//Chapter 8, Objects
	



//runPage
/*
function runPage() {
	myObject();
}
*/

//Event Listeners
//window.addEventListener("load", runPage);
//submit.addEventListener("click", customerInfo);