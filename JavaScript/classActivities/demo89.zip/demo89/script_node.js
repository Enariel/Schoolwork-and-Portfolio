//Chapter 9 demo

/*
function runPage() {
	dyn.addEventListener("click", changeMe);
	findT.addEventListener("click", findTag);
	appNode.addEventListener("click", addParagraph);
}
*/

//Event Listeners
//window.addEventListener("load", runPage);
