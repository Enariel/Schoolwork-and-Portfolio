﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SimpleCalculator
{
    public partial class frmCalculator : Form
    {
        // Oliver (Matthew) Conover
        // 6-1 Simple Calculator
        // C#
        // Brioso

        private decimal num1, num2, result;
        private string operand, sResult;
        public frmCalculator()
        {
            InitializeComponent();
        }

        private void calcButton_Click(object sender, EventArgs e)
        {
            num1 = Convert.ToInt32(firstNumBox.Text);
            num2 = Convert.ToInt32(secNumBox.Text);

            //Failsafe, wont perform function without numbers
            if (firstNumBox.Text != "" && secNumBox.Text != "")
            {
                operand = opBox.Text;
                DoMath(num1, num2, operand);
                //Format String
                sResult = result.ToString("0.####");
                resultBox.Text = sResult;
            }
        }

        //Case-Switch to for the operations 
        private void DoMath(decimal x1, decimal x2, string op)
        {
            switch (op)
            {
                case "+":
                    result = Add(x1, x2);
                    break;
                case "-":
                    result = Subtract(x1, x2);
                    break;
                case "*":
                    result = Multiply(x1, x2);
                    break;
                case "/":
                    result = Divide(x1, x2);
                    break;

            }
        }
        //Maths
        private decimal Add(decimal num1, decimal num2)
        {
            decimal x = num1 + num2;
            return x; 
        }

        private decimal Subtract(decimal num1, decimal num2)
        {
            decimal x = num1 - num2;
            return x;
        }
        private decimal Multiply(decimal num1, decimal num2)
        {
            decimal x = num1 * num2;
            return x;
        }
        private decimal Divide(decimal num1, decimal num2)
        {
            decimal x = num1 / num2;
            return x;
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
